package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserController {
    public void logIn(HttpServletRequest request, HttpServletResponse response) {}
    public void about(HttpServletRequest request, HttpServletResponse response) {}
    public void register(HttpServletRequest request, HttpServletResponse response) {}
}
