package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TaskController {
    public void addNewTask(HttpServletRequest request, HttpServletResponse response) {}
    public void taskList(HttpServletRequest request, HttpServletResponse response) {}

}
