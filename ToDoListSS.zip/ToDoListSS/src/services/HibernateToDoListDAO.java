package services;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import model.IToDoListDAO;
import model.TdlTask;
import model.Users;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;

public class HibernateToDoListDAO implements IToDoListDAO {

    ArrayList <TdlTask> taskList = new ArrayList<>();
    public static final HibernateToDoListDAO INSTANCE = new HibernateToDoListDAO();
    private static SessionFactory userFactory;
    private static SessionFactory taskFactory;


    public static HibernateToDoListDAO getInstance() {
        return INSTANCE;
    }

    private HibernateToDoListDAO() {
    }


    @Override
    public void addNewUser(Users user) {

    }

    @Override
    public Users getUser(String email, String password) {
        return null;
    }

    @Override
    public void deleteUser(Users user) {

    }

    @Override
    public void addTask(TdlTask task) {

    }

    @Override
    public void deleteTask(String userName, int taskID) {

    }

    @Override
    public void updateTask(int taskID, TdlTask updatedTask) {

    }

    @Override
    public List<TdlTask> getTasks(String userName) {
        return null;
    }

    //
//    public static void main(String[] var0) {
//
//        SessionFactory var1 = (new AnnotationConfiguration()).configure().buildSessionFactory();
//        Session var2 = var1.openSession();
//        var2.beginTransaction();
////        TdlTask var3 = new TdlTask(1, "fontana rozana chaha");
////        TdlTask var4 = new TdlTask(2, "tablox gogox");
////        TdlTask var5 = new TdlTask(3, "deluxa beda gega");
////        var2.save(var3);
////        var2.save(var4);
////        var2.save(var5);
////        var2.getTransaction().commit();
//        var2.close();
//        Session var6 = var1.openSession();
//        var6.beginTransaction();
//        List var7 = var6.createQuery("from TdlTask ").list();
//        System.out.println("There are " + var7.size() + " Task(s)");
//        Iterator var8 = var7.iterator();
//
//        while(var8.hasNext()) {
//            System.out.println(var8.next());
//        }
//
//
//        var6.close();
//    }
}
