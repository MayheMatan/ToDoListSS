package model;


public class TdlTask {

    private String task;
    private int id;
    private String taskTitle;
    private String taskDescription;

    public TdlTask() {
    }

    public TdlTask( int id, String task, String taskTitle, String taskDescription) {
        this.task = task;
        this.id = id;
        this.taskTitle = taskTitle;
        this.taskDescription = taskDescription;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTaskTitle() {
        return taskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    @Override
    public String toString() {
        return "TdlTask{" +
                "task='" + task + '\'' +
                ", id=" + id +
                ", taskTitle='" + taskTitle + '\'' +
                ", taskDescription='" + taskDescription + '\'' +
                '}';
    }
}
