package model;


import java.util.List;

public interface IToDoListDAO {

//    public void addItem();
//    public void deleteItem();
//    public void updateItem();

    //User service functions
    public void addNewUser(Users user);
    public Users getUser(String email, String password);
    public void deleteUser(Users user);

    //Task service functions
    public void addTask(TdlTask task);
    public void deleteTask(String userName, int taskID);
    public void updateTask(int taskID, TdlTask updatedTask);
    public List<TdlTask> getTasks(String userName);



}
